from numpy import number
import torch
from torchvision import models
import typing

def build_classifier(num_class: int) -> torch.nn.modules.container.Sequential:
    """
    This function builds the classifier to classify the resnet output features:

    Args:
        - num_class (int): number of class on the data to be defined as the classifier output features size

    Returns:
        - classifier (torch.nn.modules.container.Sequential): the classifier model to classify the resnet output features
    """
    # AdaptiveAvgPool2d -> damit wird auf 1x1 (HxW) feature reduziert
    classifier = torch.nn.Sequential(
        # add torch layers to build your classifier
        #torch.nn.Linear(512, num_class)
        #torch.nn.LogSoftmax(dim=1)
        torch.nn.Linear(1, 512),
        torch.nn.ReLU(),
        torch.nn.Dropout(0.2),
        torch.nn.Linear(512, num_class),
        torch.nn.LogSoftmax(dim=1)
    )
    #print(classifier)
    return classifier