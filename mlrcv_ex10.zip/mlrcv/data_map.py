class_to_lbl = {
    #define here the data classes ex.:
    # 0: "pen",
    # 1: "microphone",
    # ...
}

train_annotation = {
    #define here the train data annotations:
    # "xxx.jpg": 4,
    # "xxy.jpg": 3,
    # ...
}

val_annotation = {
    #define here the val data annotations:
    # "zzz.jpg": 0,
    # "zzw.jpg": 7,
    # ...
}