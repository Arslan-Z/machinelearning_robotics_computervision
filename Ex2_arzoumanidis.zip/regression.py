import matplotlib.pyplot as plt
import numpy as np
from typing import Optional

def rmse(y: np.ndarray, y_pred: np.ndarray) -> float:
    """
    This function should calculate the root mean squared error given target y and prediction y_pred

    Args:
        - y(np.array): target data
        - y_pred(np.array): predicted data

    Returns:
        - err (float): root mean squared error between y and y_pred

    """
    # Durchschnittliche euclidische Abweichungen zwischen dem tatsächlichen Wert und der prediction
    err = np.sqrt((1/np.shape(y)[0] * np.sum(((y - y_pred)**2))))
    
    return err

def split_data(x: np.ndarray, y: np.ndarray) -> (np.ndarray, np.ndarray, np.ndarray, np.ndarray):
    """
    This function should split the X and Y data in training, validation

    Args:
        - x: input data
        - y: target data

    Returns:
        - x_train: input data used for training
        - y_train: target data used for training
        - x_val: input data used for validation
        - y_val: target data used for validation

    """

    # Make a 10/90 % split, thereby take the first 
    # 10% of values each time for the validation set. 

    ratio_x = round((len(x) / 100) * 10)
    ratio_y = round((len(y) / 100) * 10)

    x_train = x[ratio_x:len(x)]
    y_train = y[ratio_y:len(y)]
    x_val = x[0:ratio_x]
    y_val = y[0:ratio_y]

    return x_train, y_train, x_val, y_val

class LinearRegression:
    def __init__(self):
        self.theta_0 = None
        self.theta_1 = None
        self.theta = None

    def calculate_theta(self, x: np.ndarray, y: np.ndarray):
        """
        This function should calculate the parameters theta0 and theta1 for the regression line

        Args:
            - x (np.array): input data
            - y (np.array): target data

        """
        pass

        # add dimension to x with ones
        
        expansion = np.ones((len(x),1))
        x = np.hstack((x,expansion))

        # später mehr parameter deswegen kann man 
        # gleich mehr thetas hinzfuegen und die als vecotor behandeln
        
        # Using ordinary least squares adustment
        # with y = m x + b

        # Use the normal equation -> finding the minimum is done by finding the point where the gradient is zero
        # Danach nur noch einfach einsetzen um theta_0 zu bekommen
        
        self.theta = (np.linalg.inv(x.transpose() @ x)) @ x.transpose() @ y

        self.theta_0 = self.theta[1]
        self.theta_1 = self.theta[0]
         
        #self.theta_0 = np.subtract(x, (x.transpose() * self.theta_1)) 


    def predict_y(self, x: np.ndarray) -> np.ndarray:
        """
        This function should use the parameters theta0 and theta1 to predict the y value given an input x

        Args:
            - x: input data

        Returns:
            - y_pred: y computed w.r.t. to input x and model theta0 and theta1

        """

        expansion = np.ones((len(x),1))
        x = np.hstack((x,expansion))

        # Can also be calculated with the matrix multiplication right away instead of adding
        # Here I do not need the extented column with ones
        # Use the function as stated in the lecture
        # Führt das ja für jeden Wert aus
        #y_pred = (np.transpose(x) * self.theta_1) + self.theta_0

        y_pred = (x @ self.theta)

        #Vertical mal horizontal
        #wrote down dimensions

        # Wichtig für mein Verständnis!
        # Ziel des ganzen ist, du gibst ihm x und f(x) predicted dir y 

        #Every layer has a dimension

        return y_pred

class NonLinearRegression:
    def __init__(self):
        self.theta = None

    def calculate_theta(self, x: np.ndarray, y: np.ndarray, degree: Optional[int] = 2):
        """
        This function should calculate the parameters theta for the regression curve.
        In this case there should be a vector with the theta parameters (len(parameters)=degree + 1).

        Args:
            - x: input data
            - y: target data
            - degree (int): degree of the polynomial curve

        Returns:
        """

        # Increment by 1
        degree = degree

        # We need to do polynominal transformation
        for counter in range(degree):
            expansion = np.ones((len(x),1))
            x = np.hstack((x,expansion))
            if counter > 0:
                for each_element in range(len(x[:,0])):
                    x[each_element, counter] = (x[each_element, 0])**(counter + 1)
                
        self.theta = (np.linalg.inv(x.transpose() @ x)) @ x.transpose() @ y

        return self.theta

    def predict_y(self, x: np.ndarray, degree: int) -> np.ndarray:
        """
        This function should use the parameters theta to predict the y value given an input x

        Args:
            - x: input data

        Returns:
            - y: y computed w.r.t. to input x and model theta parameters
        """
        for counter in range(degree):
            expansion = np.ones((len(x),1))
            x = np.hstack((x,expansion))
            if counter > 0:
                for each_element in range(len(x[:,0])):
                    x[each_element, counter] = (x[each_element, 0])**(counter + 1)


        y_pred = (x @ self.theta)

        return y_pred
