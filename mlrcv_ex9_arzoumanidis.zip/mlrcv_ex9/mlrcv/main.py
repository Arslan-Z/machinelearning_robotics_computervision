import torch
import pytorch_lightning as pl
from pytorch_lightning.loggers import TensorBoardLogger
import numpy as np
import torchvision
from torchvision import transforms
import matplotlib.pyplot as plt
from model import CenterNet, VOCollation
from utils import *
from loss import *
from trainer import CenterNetTrainer

transform = transforms.Compose([
        transforms.ColorJitter(brightness=0.05, contrast=0.05, saturation=0.05, hue=0.05)
    ])

train_data = torchvision.datasets.VOCDetection('./data', year='2007', image_set='train', transform=transform)
train_loader = torch.utils.data.DataLoader(train_data,
                                        batch_size=2,
                                        shuffle=True,
                                        collate_fn=VOCollation(),
                                        num_workers=4)

test_data = torchvision.datasets.VOCDetection('./data', year='2007', image_set='test')
test_loader = torch.utils.data.DataLoader(test_data,
                                        batch_size=2,
                                        collate_fn=VOCollation(),
                                        num_workers=4)

lr = 5e-4
epochs = 500

model = CenterNet()#.cuda()
centernet = CenterNetTrainer(model, centerloss, (1.0, 0.5), train_loader, test_loader, lr, epochs)

trainer = pl.Trainer(max_epochs=epochs, check_val_every_n_epoch=50)
trainer.fit(centernet)
