while getopts p: flag
do
    case "${flag}" in
        p) path=${OPTARG};;
        esac
done

zip ex6_mlrcv.zip $path/*.py $path/dataloader/*.py $path/gan/*.py