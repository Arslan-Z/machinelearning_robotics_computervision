import numpy as np
import torch
from typing import Optional
import math

def heatmap_object(img: np.ndarray, bounding_box: dict, heatmap: np.ndarray) -> np.ndarray:
    """
    This function generates the heatmaps over the objects given the input image:

    Args:
        - img (np.ndarray): input image
        - bounding_box (dict): labels with one object bounding box
        - heatmap (np.ndarray): heatmap of the current input img

    Returns:
        - heatmap (np.ndarray): output heatmap with the current object heatmap added
    """

    # image is 512x512x3
    # heatmap is 128x128
    # the bbox is {'bndbox': {'xmax': 128, 'xmin': 3, 'ymax': 128, 'ymin': 60}, 'center': (65, 94)}

    # also die gaussverteiling in 2d muss eigentlich nur auf dem center ansetzten (daher die heat map)
    # also auf dem heatmap center ist gleich dem image center geteilt duch 4, sodass damit alle 
    # Parameter die übergegeben werden auch genutzt sind, dann ist die frage, sollte ich die werte der
    # bbox vorher noch durch vier teilen müssen? nein muss ich nicht, die werte wurden schon umgerechnet
    # aber die heatmap ist doch dann schon in den richtigen dimensionen

    # wahrscheinlich brauche ich das bild immer wieder um die dimensionen der Heatmap zu reduzieren

    # lambda x : math.exp(-(1/2)*(x**2)) -> function for a gaussian distribution

    # sigma needed to control the size of the distribution
    # can be done in a variable way in order to react on the 
    # sizes of the bbox (e.g. smaller bbox area = smaller sigma)

    '''
    
    sigma = 15

    # get the necessary parameters to initialize the gaussian distributions 
    extent = np.shape(heatmap)[0] 
    center = bounding_box['center']
    
    # iterate over every pixel to add the gaussian probabilities according to the center
    for i in range(extent):
        for j in range(extent):
            heatmap[i, j] = 0.5 / np.pi / (sigma ** 2) * math.exp(-0.5 * ((i - center[0] - 0.5) ** 2 + (j - center[1] - 0.5) ** 2) / (sigma ** 2))

    heatmap = (heatmap / np.max(heatmap) * 255).astype(np.uint8)

    '''
    '''
    sigma = 15

    # get the necessary parameters to initialize the gaussian distributions 
    extent_x = bounding_box['bndbox']['xmax'] - bounding_box['bndbox']['xmin']
    extent_y = bounding_box['bndbox']['ymax'] - bounding_box['bndbox']['ymin']
    center = bounding_box['center']

    
    # iterate over every pixel to add the gaussian probabilities according to the center
    for i in range(extent_y):
        for j in range(extent_x):
            heatmap[i, j] = 0.5 / np.pi / (sigma ** 2) * math.exp(-0.5 * ((i - extent_y/2 - 0.5) ** 2 + (j - extent_x/2 - 0.5) ** 2) / (sigma ** 2))

    heatmap = (heatmap / np.max(heatmap) * 255).astype(np.uint8)

    '''
    #sigma = 15

    # get the necessary parameters to initialize the gaussian distributions 
    extent_x = bounding_box['bndbox']['xmax'] - bounding_box['bndbox']['xmin']
    extent_y = bounding_box['bndbox']['ymax'] - bounding_box['bndbox']['ymin']


    #sigma_controll = (np.sqrt(extent_x**2) + np.sqrt(extent_y**2)) / 2

    sigma = np.minimum(extent_x,extent_y) / 3

    center = bounding_box['center']

    # also die BBox hat ja schon die richtigen Dimensionen für die heatmap
    
    # iterate over every pixel to add the gaussian probabilities according to the center
    for i in range(np.shape(heatmap)[0]):
        for j in range(np.shape(heatmap)[0]):
            heatmap[j, i] = 0.5 / np.pi / (sigma ** 2) * math.exp(-0.5 * ((i - center[0] ) ** 2 + (j - center[1] ) ** 2) / (sigma ** 2))

    heatmap = (heatmap / np.max(heatmap) * 255).astype(np.uint8)


    return heatmap

def sizemap_object(img: np.ndarray, bounding_box: dict, sizemap: np.ndarray) -> np.ndarray:
    """
    This function generates the sizemaps over the objects given the input image:

    Args:
        - img (np.ndarray): input image
        - bounding_box (dict): labels with one object bounding box
        - sizemap (np.ndarray): sizemap of the current input img

    Returns:
        - sizemap (np.ndarray): output sizemap with the current object sizemap added
    """

    # the size depends on the bounding box extend

    center_x = bounding_box['center'][1]
    center_y = bounding_box['center'][0]

    sizemap[center_x, center_y][0] = bounding_box['bndbox']['xmax'] - bounding_box['bndbox']['xmin']
    sizemap[center_x, center_y][1] = bounding_box['bndbox']['ymax'] - bounding_box['bndbox']['ymin']


    return sizemap