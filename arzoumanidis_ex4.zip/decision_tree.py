import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import typing
import math
from core import *

class TreeNode:
    def __init__(self, node_id: str, max_degree: int):
        """
        This function initializes the TreeNode class (already implemented):

        Args:
            - node_id (str): node id to identiy the current node
            - max_degree (int): max degree of the tree so the depth of the tree respectively

        Returns:
        """

        # Attribute im Baum für die ich die Werte update
        self.max_attr_gain = -np.inf
        self.attr_split = None
        self.attr_split_val = None
        self.node_class = None
        self.children = {}
        self.leaf = False
        self.node_id = node_id
        self.max_degree = max_degree

        # Decision boundaries muessen mit initialisiert werden wenn die test daten durchlaufen

    def infer_node(self, x: np.ndarray) -> float:
        """
        This function goes over the tree given the input data x and return the respective leaf class (only returns node_class after reaching a leaf):
        quasi das predict
        Args:
            - x (np.ndarray): input data x to be checked over the tree

        Returns:
            - node_class (float): respective leaf class given input x
        """
        # bestimme die klasse für alle leaves des baumes (Siehe vorlesung 3 folie 14)
        # if it is called for a leaf directly that return the class imediately 
        # für x gehe ich alle kinder ab bis ich beim leaf bin
        # ich betrachte vom children vom childeren (so gehe ich die Ebenen tiefe)
        
        if self.leaf == True:
            node_class = self.node_class
        elif x[self.attr_split] >= self.attr_split_val:
            node_class = self.children['right_node'].infer_node(x)
        else:
            node_class = self.children['left_node'].infer_node(x)


        # Alle funktionen hier ineinander aufrufen und fuer test daten predicten
        # Wenn der Baum schon steht 

        # Implicit, d.h. Decision boundaries über testdaten 
        # Split funktion über trainingsdaten 
        # 

        return node_class

    def split_node(self, x: np.ndarray, y: np.ndarray, degree: int):
        """
        This function uses the current x and y data to split the tree nodes (left and right) given the information_gain
        calculated over the possible splits. Recursion stop condition will be when the current degree arrives at
        maximum degree (setting it as leaf):
        Build den gesammten Tree

        Args:
            - x (np.ndarray): input data x to be splited
            - y (np.ndarray): class labels of the input data x
            - degree (int): current node degree

        Returns:
        """

        '''
                if degree == self.max_degree:

            # majority vote which class the test value should be predicted
            left_node.leaf = True
            index = np.argmax(np.unique(y_l, return_counts = True)[1])
            self.node_class = np.unique(y_l)[index-1]

            right_node.leaf = True
            index = np.argmax(np.unique(y_r, return_counts = True)[1])
            right_node.node_class = np.unique(y_r)[index-1]

        '''

        if degree == self.max_degree:

            # majority vote which class the test value should be predicted
            self.leaf = True
            index = np.argmax(np.unique(y, return_counts = True)[1])
            self.node_class = np.unique(y)[index-1]
            return


        # Create left and right node for the Decision tree
        left_node = TreeNode('left_node', self.max_degree)
        right_node = TreeNode('right_node', self.max_degree)

        self.children = {'right_node' : right_node, 'left_node' : left_node}

        # Go over all dimensions and find the highest attribute value
        for k in range(np.shape(x)[1]):
            split_gain, split_value = self.attr_gain(x[:,k],y)
            if split_gain > self.max_attr_gain:
                self.max_attr_gain, self.attr_split_val = split_gain, split_value
                self.attr_split = k

        # Split the values according to the max attribute value (eigentlicher Split)
        # Es müsste nur so sein, dass ja die Werte für beide 
        # Dimensionen auf die beiden Subsets (links und rechts) aufteilen müsste
        y_l = y[x[:,self.attr_split] < self.attr_split_val]
        x_l = x[x[:,self.attr_split] < self.attr_split_val]

        x_r = x[x[:,self.attr_split] >= self.attr_split_val]
        y_r = y[x[:,self.attr_split] >= self.attr_split_val]

        # do the recursion to find the class later
        if y_l.shape[0] == 0 or y_r.shape[0] == 0:    
            self.leaf = True
            # Letzter übergebener Wert (Subset von y)
            index = np.argmax(np.unique(y, return_counts = True)[1])
            self.node_class = np.unique(y)[index-1]
            
        else:
            left_node.split_node(x_l,y_l, degree= degree + 1)
            right_node.split_node(x_r,y_r, degree= degree + 1)

        return 

    def attr_gain(self, x_attr: np.ndarray, y: np.ndarray) -> (float):
        """
        Splitte ein einziges feature (dimension) in meinem feature vector
        x_d. Ein Baum splitted immer nach den Dimensionen (hyperparamter)

        This function calculates the attribute gain:

        Args:
            - x_attr (np.ndarray): input data x[attr] to be splitted
            - y (np.ndarray): labels of the input data x

        Returns:
            - split_gain (float): highest gain from the possible attributes splits
            - split_value (float): split value selected for x_attr attribute (das ist mein tau)
        """

        # Initialize for first run
        split_gain = -np.inf
        split_value = -np.inf

        y_l = np.array([])
        y_r = np.array([])

        # Nur aufteilen der labels in das linke oder rechte subset
        for i in range(len(x_attr)):
            tau= x_attr[i]

            y_l = y[x_attr < tau]
            y_r = y[x_attr >= tau]
           
            inf_gain = self.information_gain(y, y_l, y_r)
            
            if inf_gain > split_gain:
                split_gain = inf_gain
                split_value = tau


        return split_gain, split_value

    def information_gain(self, y: np.ndarray, y_l: np.ndarray, y_r: np.ndarray) -> float:
        """
        This function calculates the attribute gain from the candidate splits y_l and y_r:
        0 or 1 (left or right) Threshold tau

        Args:
            - y (np.ndarray): the full labels of the current node
            - y_l (np.ndarray): labels of the candidate left node split
            - y_r (np.ndarray): labels of the candidate right node split

        Returns:
            - I (float): information gain from the candidate splits y_l and y_r
        """
        I = self.entropy(y) - ( ((len(y_l) / len(y)) * self.entropy(y_l))  + ((len(y_r) / len(y)) * self.entropy(y_r)) )

        return I

    def entropy(self, y: np.ndarray) -> float:
        """
        This function calculates the entropy from the input label set y:
        Provides measure of the "information" in a subset of labels

        Args:
            - y (np.ndarray): the label set to calculate the entropy

        Returns:
            - H (float): the entropy of the input labels set y
        """

        # Store the number of labels
        n_labels = len(y)

        # If labels are empty or only one label than we have no more information we
        # can gain because we know everything already
        if n_labels <= 1:
            return 0

        # Compute entropy as explained by Mr. Behley in third lecture (slide 17 - 20mins)
        # for set y determine the probability that P(y = k) which is the categorical distribution 
        # we count how many of the y = k and devide this by the number of all lables n_labels
        value, counts = np.unique(y, return_counts=True)
        probs = counts / n_labels
        n_classes = np.count_nonzero(probs)

        # can also be solved with looping over all classes and counting and then in the end deviding

        # If a class has no or only one values return entropy zero because we have no more information we
        # can gain because we know everything already
        if n_classes <= 1:
            return 0  

        # Initialize H 
        H = 0.

        # Compute entropy as explained by Mr. Behley in third lecture (slide 17 - 20mins)
        # Multiply the entropy values
        for i in probs:
            H -= i * math.log(i, 2)

        return H


class DecisionTree:
    def __init__(self, num_class: int, max_degree: int):
        """
        This function initializes the DecisionTree class (already implemented):

        Args:
            - num_class (int): number of class from your data
            - max_degree (int): max degree of the tree

        Returns:
        """
        self.root = None
        self.max_degree = max_degree
        self.num_class = num_class
    
    def fit(self, x: np.ndarray, y: np.ndarray):
        """
        This function fits the decision tree with the training data x and labels y. Starting from root tree node,
        and iterate recursively over the nodes, split on left and right nodes:

        Args:
            - x (np.ndarray): the full labels of the current node
            - y (np.ndarray): labels of the candidate left node split

        Returns:

        """
        # Start at node (Wurzel den Baum aufbauen)
        self.root = TreeNode(1,self.max_degree)
        self.root.split_node(x,y, 0)

        return 

    def predict_y(self, x: np.ndarray) -> np.ndarray:
        """
        This function predicts y_pred class from the input x:

        Args:
            - x (np.ndarray): input data to be predicted by the tree

        Returns:
            - y_pred (np.ndarray): tree predictions over input x
        """
        y_pred = np.zeros(np.shape(x)[0])
        
        for i in range(np.shape(x)[0]):
            y_pred[i] = self.root.infer_node(x[i])
        
        return y_pred

    def eval(self, x: np.ndarray, y: np.ndarray):
        """
        This function evaluate the model predicting y_pred from input x and calculating teh accuracy between y_pred and y:

        Args:
            - x (np.ndarray): input data to be predicted by the tree
            - y (np.ndarray): input class labels

        Returns:
            - acc (float): accuracy of the model
        """
        return accuracy(y, self.predict_y(x))
