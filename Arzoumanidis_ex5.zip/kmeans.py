import numpy as np
import pandas as pd
from core import *
from typing import Optional

class KMeans:
    def __init__(self, k_clusters: int, max_iter: Optional[int] = 300, init_method: Optional[str] = 'rand'):
        """
        This function initializes the KMeans method:

        Args:
            - k_clusters (int): number of cluster to divide your data
            - max_iter (int): max number of iterations to define the clusters
            - init_method (str): method to initialize the cluster centers (rand or k++)

        Returns:
        """
        self.k_clusters = k_clusters
        self.max_iter = max_iter
        self.k_centers = None
        self.init_method = init_method
        self.init_dict = {'rand': self.init_random_centers, 'k++': self.init_centers_kpp}

    def euclidean_distance(self, x: np.ndarray, center: np.ndarray) -> np.ndarray:
        """
        This function computes the euclidean distance between every point in x to the center:

        Args:
            - x (np.ndarray): input points x
            - center (np.ndarray): cluster center to compute the euclidean distance

        Returns:
           - dist (np.ndarray): the euclidean distance of each x point to the center 
        """

        # Meine Implementierung kann so z.B. gleich für mehrere Cluster eingesetzt werden

        #print(np.shape(center))

        dist = np.zeros((np.shape(x)[0],np.shape(center)[0])) 
        
        for mean in range(len(center)):
            for point in range(len(x)):
                dist[point,mean] = np.sqrt((self.k_centers[mean,0] - x[point,0])**2 + (self.k_centers[mean,1] - x[point,1])**2)
        
        return dist

    def init_centers_kpp(self, x: np.ndarray):
        """
        This function initialize the clusters centers using the KMeans++ method (farthest point sampling). Instead of 
        randomly initialize the centers this method gets the first center as a random sample of x then computes the distance
        of every other x sample to the already defined centers, then use the calculated distance as a probability
        distribution to pick other sample as the next center (repeat until define the K initial centers):
        

        Args:
            - x (np.ndarray): input points x

        Returns:
        """

        # implement here your function
        
        """
        plot the initial centers, should be at the end of your function so you can see where are the initial centers
        """
        #print('Initial centers from k++ initialization')
        #plot_clusters(x, self)

        x_random = x
        
        # Initialize with (3x2) and select the first value random
        self.k_centers = np.zeros((self.k_clusters,2))
        np.random.shuffle(x_random)
        self.k_centers[0,:] = x_random[0:1,:]
        #print(self.k_centers)
        #print(x[0:1,:],'random wert')


        for init_cluster in range(self.k_clusters-1):

            dist = self.euclidean_distance(x,self.k_centers[0:init_cluster+1])
            #print(self.k_centers, 'so sieht meine center function aus')
            #print(self.k_centers[0:init_cluster+1],'das übergebe ich meiner dist function')

            #print(np.shape(dist))
            #print(np.shape(dist)[1])
            
            totalmax = 0
            totalmax_index = 0
            for maxindex in range(np.shape(dist)[1]):
                currentmax = np.max(dist[:,maxindex])
                currentmax_index = np.argmax(dist[:,maxindex])
                if currentmax >= totalmax:
                    totalmax = currentmax
                    totalmax_index = currentmax_index

            self.k_centers[init_cluster+1] = x[totalmax_index]
            #print(self.k_centers, "wert von kcenter nach iteriert")
            #print('---------------------------------------------------------')
        
        #print(self.k_centers, "wert von kcenter nach iteriert")



    def init_random_centers(self, x: np.ndarray):
        """
        This function randomly initializes the K initial centers

        Args:
            - x (np.ndarray): input points x

        Returns:
        """
        
        np.random.shuffle(x)
        self.k_centers = x[0:self.k_clusters,:]

        
        """
        plot the initial centers, should be at the end of your function so you can see where are the initial centers
        """
        #print('Initial centers from random initialization')
        #plot_clusters(x, self)

    def fit(self, x: np.ndarray):
        """
        This function uses the input x data to define the K clusters centers. Iterate over x, compute the points
        distances to the center, assign the clusters points, and update the clusters centers (repeat until convergence
        or reach the max_iter):

        Args:
            - x (np.ndarray): input points x

        Returns:
        """

        # implement here your function

        """
        you can use the plot_clusters(x, self) function call inside your training loop to check how the 
        clusters behave while updating
        """
        # plot_clusters(x, self)

        # Init the initial clusters with the selected methode
        self.init_dict[self.init_method](x)

        # Init the new coloumn in which to store the corresponding cluster 
        # for that point
        x = np.c_[ x, np.ones(len(x)) ]
        x[:,2] = np.inf
        dist = 0

        # Max iteration
        for it in range(self.max_iter):

            old_dist = dist

            dist = self.euclidean_distance(x[:,0:2],self.k_centers)

            val = dist - old_dist

            # Max convergence
            if 0.001 >= val.any():
                break

            for l in range(len(x)):
                x[l,2] = np.argmin(dist[l,:])
            

            # Here comes the update similar to GMM
            for update in range(np.shape(self.k_centers)[0]):
                self.k_centers[update,:] = np.mean(x[x[:,2] == update], axis=0)[0:2]

        
        return x



    def predict_c(self, x: np.ndarray) -> np.ndarray:
        """
        This function predicts to which cluster each point in x belongs

        Args:
            - x (np.ndarray): input points x

        Returns:
            - c_pred (np.ndarray): assigned clusters to each point in x
        """

        c_pred = self.fit(x)[:,2]

        return c_pred
