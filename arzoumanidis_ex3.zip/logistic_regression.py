import numpy as np
import matplotlib.pyplot as plt
from core import *
import typing

def split_data(x: np.ndarray, y: np.ndarray) -> (np.ndarray, np.ndarray, np.ndarray, np.ndarray):
    """
    This function should split the X and Y data in training and validation sets

    Args:
        - x (np.ndarray): set of points x1 and x2
        - y (np.ndarray): class labels of each sample

    Returns:
        - X_train, Y_train (np.ndarray, np.ndarray): input data and labels to be used for training
        - X_val, Y_val (np.ndarray, np.ndarray): input data and labels to be used for validation
    """

    ratio_x = round((len(x) / 100) * 20)

    ratio_x = len(x) - ratio_x

    index = np.random.permutation(x.shape[0])
    
    training_idx, test_idx = index[:ratio_x], index[ratio_x:]

    x_train, x_val = x[training_idx,:], x[test_idx,:]

    y_train, y_val = y[training_idx,:], y[test_idx,:]


    return x_train, y_train, x_val, y_val

def sigmoid(x: np.ndarray) -> np.ndarray:
    """
    This function should calculate the sigmoid activation function w.r.t. x

    Args:
        - x (np.ndarray): vector with float values to calculate the sigmoid function

    Returns:
        - sigmoid_x (np.ndarray): output vector with the values sigmoid(x)
    """

    # Nachsehen ob das auch wirklich für alle features von x gilt und
    # ob die auch richtig indiziert werden oder ob man da noch nachbessern muss

    sigmoid_x = 1 / ( 1 + (np.exp(-x)))

    return sigmoid_x

def softmax(x: np.ndarray) -> np.ndarray:
    """
    This function should calculate the softmax activation function w.r.t. x

    Args:
        - x (np.ndarray): vector with float values to calculate the softmax function

    Returns:
        - softmax_x (np.ndarray): output vector with the values softmax(x)
    """

    # Siehe online Implementierung von softmax
    softmax_x = np.exp(x - np.max(x))
    softmax_x = softmax_x / softmax_x.sum(axis = 0)

    return softmax_x

class LogisticRegression:
    def __init__(self, learning_rate: float, epochs: int):
        """
        This function should initialize the model parameters

        Args:
            - learning_rate (float): the lambda value to multiply the gradients during the training parameters update
            - epochs (int): number of epochs to train the model

        Returns:
        """

        self.learning_rate = learning_rate
        self.epochs = epochs

        # Initializiere theta weil wir theta nicht direct und optimal bestimmen können
        # sondern nur optimiert näherungsweise bestimmen können (deswegen 0)

        self.theta = np.array([0,0,0])
        self.theta = self.theta.reshape(3,1)


    def predict_y(self, x: np.ndarray) -> np.ndarray:
        """
        This function should use the parameters theta to predict the y class given an input x

        Args:
            - x (np.ndarray): input data to predict y classes

        Returns:
            - y_pred (np.ndarray): the model prediction of the input x
        """

        y_pred = sigmoid(self.theta.T @ x.T) 

        # Nehme die Trainierten thetas von vorher und berechne die Distanz zur Line um die Klassen der test daten zu bestimmen
        # Initialize theta with 0, because we do not have a closed solution (we need to optimize)
        # Predict binary with P(y|x) and sigmoid Gives you values and asks you to split them

        return y_pred

    def first_derivative(self, x: np.ndarray, y_pred: np.ndarray, y: np.ndarray) -> np.ndarray:
        """
        This function should calculate the first derivative w.r.t. input x, (predicted y and true labels y)

        Args:
            - x (np.ndarray): input data
            - y_pred (np.ndarray): predictions of x
            - y (np.ndarray): true labels of x

        Returns:
            - der (np.ndarray): first derivative value
        """
    
        # Der derivative (erste Ableitung) ist hier nur die prediction minus das tatsächliche
        # und das Ergebnis multipliziert mit x also dem feature vector mit seinen features

        der = (y_pred - y.T) @ x

        return der

    def train_model(self, x: np.ndarray, y: np.ndarray):
        """
        This function should train the model to find theta parameters that best fit the data

        Args:
            - x (np.ndarray): input data to predict y classes
            - y (np.ndarray): true labels of x
        """

        # "Training" ist hierbei der gradient Descent also die optimierung ist das lernen
        # weil wir ja theta optimal bestimmen wollen  (also erlernen)

        expansion = np.ones((len(x),1))
        x = np.hstack((expansion,x))

        for counter in range(self.epochs):
            self.theta = self.theta - (self.learning_rate * self.first_derivative(x,self.predict_y(x),y).T)



    def eval(self, x: np.ndarray, y: np.ndarray) -> float:
        """
        This function should evaluate the model and output the accuracy of the model
        (accuracy function already implemented)

        Args:
            - x (np.ndarray): input data to predict y classes
            - y (np.ndarray): true labels of x

        Returns:
            - acc (float): accuracy of the model (accuracy(y,y_pred)) note: accuracy function already implemented in core.py
        """
        expansion = np.ones((len(x),1))
        x = np.hstack((expansion,x))

        acc = accuracy(y, self.predict_y(x))

        return acc

class MultiClassLogisticRegression:
    def __init__(self, learning_rate: float, epochs: int):
        """
        This function should initialize the model parameters

        Args:
            - learning_rate (float): the lambda value to multiply the gradients during the training parameters update
            - epochs (int): number of epochs to train the model

        Returns:
        """
        self.learning_rate = learning_rate
        self.epochs = epochs
        # num_class = 3
        self.theta_class = np.zeros((3,3))
        #self.theta_class = self.theta_class.reshape(3,1)

    def predict_y(self, x: np.ndarray) -> np.ndarray:
        """
        This function should use the parameters theta to predict the y class given an input x

        Args:
            - x (np.ndarray): input data to predict y classes

        Returns:
            - y_pred (np.ndarray): the model prediction of the input x
        """

        # Hier softmax funktion ich multipliziere alle jedes theta mit allen
        # Werten aus den test feature values anschließend für jeden der Werte
        # in der softmax die distance zur Line als Wahrscheinlichkeit ausdrücken 

        y_pred = softmax(self.theta_class.T @ x.T)

        #y_pred = np.squeeze(y_pred)
        
        #print(np.shape(y_pred),"pred")

        return y_pred

    def first_derivative(self, x: np.ndarray, y_pred: np.ndarray, y: np.ndarray) -> np.ndarray:
        """
        This function should calculate the first derivative w.r.t. input x, predicted y and true labels y,
        for each possible class.

        Args:
            - x (np.ndarray): input data
            - y_pred (np.ndarray): predictions of x
            - y (np.ndarray): true labels of x

        Returns:
            - der: first derivative value
        """
        #print(np.shape(y_pred - y.T),'y_pred - y',np.shape(x),'x')

        der = (y_pred - (y.T)) @ x

        #print(np.shape(der))

        #print(np.shape(y_pred - y.T),'y_pred - y',np.shape(x.T),'x')

        return der

    def train_model(self, x: np.ndarray, y: np.ndarray):
        """
        This function should use train the model to find theta_class parameters (multiclass) that best fit the data

        Args:
            - x (np.ndarray): input data to predict y classes
            - y (np.ndarray): true labels of x
        """

        expansion = np.ones((len(x),1))
        x = np.hstack((expansion,x))

        for counter in range(self.epochs):
            self.theta_class = self.theta_class - (self.learning_rate * self.first_derivative(x,self.predict_y(x),y).T)

        # Update each time 

    def eval(self, x: np.ndarray, y: np.ndarray) -> float:
        """
        This function should use evaluate the model and output the accuracy of the model
        (accuracy function already implemented)

        Args:
            - x (np.ndarray): input data to predict y classes
            - y (np.ndarray): true labels of x

        Returns:
            - acc (float): accuracy of the model (accuracy(y,y_pred)) note: accuracy function already implemented in core.py
        """

        expansion = np.ones((len(x),1))
        x = np.hstack((expansion,x))

        acc = accuracy(y, self.predict_y(x))

        return acc

    # Mit dem self beschränke ich mich auf die Methoden
    # welche sich in dieser Klasse befinden        